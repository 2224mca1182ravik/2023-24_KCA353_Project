# Clinic / Medical / Hospital Management System in php

Clinic / medical Management System in php By Code Camp BD <br/>

## Available Features:

<li>Admin Panel <br/> 
<li>Employee Panel <br/> 
<li>Patient Management <br/> 
<li>Transfer, Discharge Patient <br/> 
<li>Employee Management <br/> 
<li>Assign Departments <br/> 
<li>Transfer Employees <br/> 
<li>Medicine Management <br/> 
<li>Prescriptions <br/> 
<li>Accounting – Payable and Receivable <br/> 
<li>Inventory Management <br/> 
<li>Assets Management <br/> 
<li>In and Out Patient Records <br/> 
<li>Medical Records <br/> 
<li>Patient Lab Test and Results <br/> 
<li>Manage Patient’s Vitals <br/> 
<li>Lab Reports <br/> 
<li>Surgery Records <br/> 
<li>Surgery Equipment Records <br/> 
<li>Patient Medical Profile <br/> 
<li>Payroll Management <br/> 
<li>Print Payroll Receipt <br/> 
<li>Manage Vendors <br/>

## Admin Login Info Details

userName: admin@ccbd.com <br/> passWord: Watch Youtube <a href = "https://youtu.be/8ipv81cdGSE" target="_blank"> Video </a> <br/>

## Doctor Login Info Details <br/>

userName: ccbd <br/> passWord: Watch Youtube <a href = "https://youtu.be/8ipv81cdGSE"> Video </a>

Subcribe my You tube Channel ** Subscribe **

Author : MH RONY <br/> Website Link: https://developerrony.com <br/> GitHub Link: https://github.com/dev-mhrony <br/> Youtube Video Link: <br/> https://www.youtube.com/channel/UChYhUxkwDNialcxj-OFRcDw <br/> Youtube Channel Link <br/> https://www.youtube.com/channel/UChYhUxkwDNialcxj-OFRcDw <br/>

![screencapture-localhost-Hospital-PHP-backend-doc-index-php-2023-01-24-21_54_48](https://user-images.githubusercontent.com/78216965/214342824-414b2f18-45df-409e-be9c-81f48da78ddd.png)

![screencapture-localhost-Hospital-PHP-backend-admin-index-php-2023-01-24-21_55_10](https://user-images.githubusercontent.com/78216965/214342871-d3c5a0b0-f101-4b4b-bc4e-4165f7946d72.png)

![screencapture-localhost-Hospital-PHP-2023-01-24-21_54_34](https://user-images.githubusercontent.com/78216965/214342847-4894f773-239d-460d-9435-b13eb6d67181.png)
