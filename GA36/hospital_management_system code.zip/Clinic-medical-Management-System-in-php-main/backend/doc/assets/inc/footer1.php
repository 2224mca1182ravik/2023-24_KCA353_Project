<footer class="footer footer-alt">
    2022 - <?php echo date('Y'); ?> &copy; Hospital Management Information System. Developed By <a href="https://developerrony.com">MH RONY</a></a>

</footer>