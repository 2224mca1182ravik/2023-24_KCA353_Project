-- SQLite
DELETE from imsApp_product where id<5;